#include "pwm.h"

NRF52_MBED_Timer ITimer(NRF_TIMER_3);
NRF52_MBED_Slow_PWM ISR_PWM;

const float PWM_FREQUENCY = 500.0f;

void TimerHandler()
{
  ISR_PWM.run();
}

void setupPWM() {
  Serial.print("Setting Up PWM");
  /*if (ITimer.attachInterruptInterval(10L, TimerHandler))
  {
    Serial.print("Starting ITimer OK");
  }
  else
    Serial.println("Can't set ITimer. Select another freq. or timer");*/
}

void setVibrationInterval () {
  while (true) {
    ISR_PWM.setPWM(7, PWM_FREQUENCY, 150);
    delay(1000);
    ISR_PWM.setPWM(7, PWM_FREQUENCY, 255);
    delay(1000);
  }
}

