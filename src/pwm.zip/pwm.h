#pragma once

#include "nRF52_MBED_Slow_PWM.hpp"

void setupPWM ();

void setVibrationInterval ();